import Input from './Input/Input';

export default [Input];
